<?php
// Token fixo que o cliente precisa enviar no header Authorization
define('API_TOKEN', 'admin123');
?>
